# stems-git-gpt
offload github processes to openai
